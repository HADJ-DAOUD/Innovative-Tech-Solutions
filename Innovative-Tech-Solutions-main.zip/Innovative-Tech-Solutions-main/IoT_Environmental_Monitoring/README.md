# IoT Environmental Monitoring

Deployed IoT sensors for real-time environmental monitoring.

## Requirements
- flask
- paho-mqtt

## Usage
```bash
pip install -r requirements.txt
python iot_monitoring.py
