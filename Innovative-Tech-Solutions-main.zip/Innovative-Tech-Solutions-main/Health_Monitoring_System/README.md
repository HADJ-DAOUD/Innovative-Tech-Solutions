# Health Monitoring System

Real-time health monitoring using IoT sensors.

## Requirements
- flask
- paho-mqtt

## Usage
```bash
pip install -r requirements.txt
python health_monitoring.py
