# Sentiment Analysis

A sentiment analysis tool for social media posts.

## Requirements
- pandas
- nltk

## Usage
```bash
pip install -r requirements.txt
python sentiment_analysis.py
