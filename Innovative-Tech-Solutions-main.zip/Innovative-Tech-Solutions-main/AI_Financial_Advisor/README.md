# AI Financial Advisor

An AI model providing personalized financial advice.

## Requirements
- pandas
- tensorflow

## Usage
```bash
pip install -r requirements.txt
python ai_financial_advisor.py
